# 0x04. Loops, conditions and parsing
## Description
This project directory contains tasks that acheive the following learning objectives:

* How to create SSH keys
* What is the advantage of using `#!/usr/bin/env bash` over `#!/bin/bash`
* How to use `while`, `until` and `for` loops
* How to use `if`, `else`, `elif` and `case` condition statements
* How to use the `cut` command
* What are files and other comparison operators, and how to use them

### Featured source files
* Bash scripts

See file specifications [here](https://github.com/Samuel-IG16/alx-system_engineering-devops#readme)
