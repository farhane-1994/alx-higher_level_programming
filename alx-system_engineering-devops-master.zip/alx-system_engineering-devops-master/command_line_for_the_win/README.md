# Command line for the win
## Discription
![This is an image](cmdchallengepic.png)
[CMD CHALLENGE](https://cmdchallenge.com/) is a pretty cool game challenging you on Bash skills. Everything is done via the command line and the questions are becoming increasingly complicated. It’s a good training to improve your command line skills!

### Featured files
* Snapshots of answered questions
