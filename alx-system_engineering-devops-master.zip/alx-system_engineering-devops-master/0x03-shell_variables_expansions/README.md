Shell init, filters and expansion
